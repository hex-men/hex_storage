// frontend/script.js
const API_BASE = 'http://localhost:5000/api'; // adjust if backend deployed elsewhere
const form = document.getElementById('machineForm');
const machineSelect = document.getElementById('machineSelect');
const fieldsContainer = document.getElementById('fields');
const statusDiv = document.getElementById('status');
const submitBtn = document.getElementById('submitBtn');
const startAutoBtn = document.getElementById('startAuto');
const stopAutoBtn = document.getElementById('stopAuto');

const PARAMS = [
  "MACHINE_NAME",
  "Design",
  "Matrix Size",
  "Wire Diameter (mm)",
  "Wire Grade",
  "Spring Outer Diameter (mm)",
  "Spring Height (mm)",
  "Number of Active Coils",
  "Number of Springs",
  "Columns",
  "Rows",
  "Helix Pitch (mm)",
  "Lacing Wire Gauge (mm)",
  "Lacing Pattern",
  "Estimated Wire Usage (meters)",
  "Actual Wire Usage (meters)",
  "Operating Time (sec)",
  "Start Time",
  "Actual Units Produced",
  "Theoretical Units",
  "Machine Status",
  "Target Units",
  "Target Time (min)",
  "Working Width (mm)",
  "Air Consumption (m3/hr)",
  "Power Consumption (kVA)",
  "Voltage",
  "Frequency (Hz)",
  "Temperature (°C)",
  "Weight (kg)"
];

let autoInterval = null;
const AUTO_MS = 15000; // 15 seconds

// build form fields (two column grid)
function buildFields() {
  const frag = document.createDocumentFragment();
  for (let i = 0; i < PARAMS.length; i++) {
    const name = PARAMS[i];
    const wrapper = document.createElement('div');
    wrapper.className = 'field-row';
    // put two fields per row if possible
    const col1 = document.createElement('div'); col1.className = 'col';
    const label = document.createElement('label'); label.innerText = name;
    const input = document.createElement('input');
    input.name = name;
    input.type = name.toLowerCase().includes('units') || name.toLowerCase().includes('count') || name.toLowerCase().includes('number') || name.toLowerCase().includes('time') ? 'number' : 'text';
    col1.appendChild(label); col1.appendChild(input);
    frag.appendChild(col1);
  }
  fieldsContainer.innerHTML = '';
  fieldsContainer.appendChild(frag);
}

// restore values from localStorage
function restoreValues() {
  const saved = JSON.parse(localStorage.getItem('machineFormData') || '{}');
  if (!saved) return;
  PARAMS.forEach(p => {
    const el = document.getElementsByName(p)[0];
    if (el && saved[p] !== undefined) el.value = saved[p];
  });
  if (saved['selectedMachineId']) {
    machineSelect.value = saved['selectedMachineId'];
  }
}

// save current form state
function saveValues() {
  const data = {};
  PARAMS.forEach(p => {
    const el = document.getElementsByName(p)[0];
    data[p] = el ? el.value : '';
  });
  data['selectedMachineId'] = machineSelect.value;
  localStorage.setItem('machineFormData', JSON.stringify(data));
}

// fetch machines from backend
async function fetchMachines() {
  try {
    const res = await fetch(`${API_BASE}/machines`);
    const machines = await res.json();
    machineSelect.innerHTML = '<option value="">-- Select machine --</option>';
    machines.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m._id;
      opt.textContent = m.name;
      machineSelect.appendChild(opt);
    });
    // restore if had selection
    const saved = JSON.parse(localStorage.getItem('machineFormData') || '{}');
    if (saved && saved.selectedMachineId) {
      machineSelect.value = saved.selectedMachineId;
    }
  } catch (err) {
    console.error('Failed to fetch machines', err);
    statusDiv.innerText = 'Status: Failed to load machines';
  }
}

// create payload from form
function collectParameters() {
  const params = {};
  PARAMS.forEach(p => {
    const el = document.getElementsByName(p)[0];
    if (!el) return;
    // try to coerce numeric-looking fields
    const val = el.value;
    if (val === '') {
      params[p] = null;
    } else if (!isNaN(val) && val.trim() !== '') {
      // numeric
      params[p] = Number(val);
    } else {
      params[p] = val;
    }
  });
  return params;
}

// submit to backend
async function submitNow() {
  const machineId = machineSelect.value;
  if (!machineId) {
    statusDiv.innerText = 'Status: Select a machine first';
    return;
  }

  const parameters = collectParameters();
  saveValues();

  try {
    const res = await fetch(`${API_BASE}/submit`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ machineId, parameters })
    });

    const json = await res.json();
    if (!res.ok) {
      statusDiv.innerText = `Status: Error - ${json.message || json.error || 'Unknown'}`;
      return;
    }

    statusDiv.innerText = `Status: Submitted at ${new Date().toLocaleTimeString()}`;
    console.log('submission result', json);
  } catch (err) {
    console.error(err);
    statusDiv.innerText = 'Status: Network error while submitting';
  }
}

// handlers
form.addEventListener('submit', (e) => {
  e.preventDefault();
  submitNow();
});

startAutoBtn.addEventListener('click', () => {
  if (autoInterval) return;
  submitNow(); // submit immediately
  autoInterval = setInterval(submitNow, AUTO_MS);
  startAutoBtn.disabled = true;
  stopAutoBtn.disabled = false;
  statusDiv.innerText = 'Status: Auto-submitting every 15s';
});

stopAutoBtn.addEventListener('click', () => {
  if (!autoInterval) return;
  clearInterval(autoInterval);
  autoInterval = null;
  startAutoBtn.disabled = false;
  stopAutoBtn.disabled = true;
  statusDiv.innerText = 'Status: Auto stopped';
});

// save values when any input changes
document.addEventListener('input', (e) => {
  if (PARAMS.includes(e.target.name) || e.target === machineSelect) {
    saveValues();
  }
});

// init
buildFields();
fetchMachines().then(restoreValues);
