// backend/routes/machines.js
import express from 'express';
import { getMachines, submitParameters } from '../controllers/machinesController.js';

const router = express.Router();

// GET /api/machines -> list of { _id, name }
router.get('/machines', getMachines);

// POST /api/submit -> save parameters { machineId, parameters }
router.post('/submit', submitParameters);

export default router;
