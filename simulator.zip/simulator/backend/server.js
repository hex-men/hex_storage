// backend/server.js
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import { connectDB } from './config/db.js';
import machinesRouter from './routes/machines.js';

dotenv.config();
const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json({ limit: '2mb' })); // allow JSON body

// connect DB then start
await connectDB();

app.use('/api', machinesRouter);

app.get('/', (req, res) => res.send('Machine Dashboard API is running'));

app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});
