// backend/models/MachineSubmission.js
import mongoose from 'mongoose';

const submissionSchema = new mongoose.Schema({
  machineId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Machine',
    required: true
  },
  // store parameters as an object (schema-less so you can store all fields)
  parameters: {
    type: mongoose.Schema.Types.Mixed,
    required: true
  },
  submittedAt: {
    type: Date,
    default: Date.now
  }
});

const MachineSubmission = mongoose.model('MachineSubmission', submissionSchema);
export default MachineSubmission;
