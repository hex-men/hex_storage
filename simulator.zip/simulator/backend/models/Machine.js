// backend/models/Machine.js
import mongoose from 'mongoose';

const machineHistorySchema = new mongoose.Schema({
  time: { type: String, required: true },
  event: { type: String, required: true },
  timestamp: { type: Date, default: Date.now }
}, { _id: false });

const graphDataSchema = new mongoose.Schema({
  time: { type: String, required: true },
  value: { type: Number, required: true },
  timestamp: { type: Date, default: Date.now }
}, { _id: false });

const machineSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Machine name is required'],
    unique: true,
    trim: true
  },
  totalWireUsed: {
    type: Number,
    required: [true, 'Total wire used is required'],
    min: [0, 'Total wire used cannot be negative']
  },
  targetWire: {
    type: Number,
    required: [true, 'Target wire is required'],
    min: [1, 'Target wire must be at least 1']
  },
  efficiency: {
    type: Number,
    required: [true, 'Efficiency is required'],
    min: [0, 'Efficiency cannot be less than 0'],
    max: [100, 'Efficiency cannot exceed 100']
  },
  status: {
    type: String,
    enum: {
      values: ['online', 'offline', 'maintenance'],
      message: 'Status must be online, offline, or maintenance'
    },
    required: [true, 'Status is required'],
    default: 'online'
  },
  history: [machineHistorySchema],
  graphData: [graphDataSchema],
  lastUpdated: { type: Date, default: Date.now }
}, {
  timestamps: true
});

machineSchema.virtual('progress').get(function() {
  return (this.totalWireUsed / this.targetWire) * 100;
});

machineSchema.pre('save', function(next) {
  this.lastUpdated = new Date();
  next();
});

machineSchema.pre('findOneAndUpdate', function(next) {
  this.set({ lastUpdated: new Date() });
  next();
});

const Machine = mongoose.model('Machine', machineSchema);
export default Machine;
