// backend/controllers/machinesController.js
import Machine from '../models/Machine.js';
import MachineSubmission from '../models/MachineSubmission.js';

export async function getMachines(req, res) {
  try {
    const machines = await Machine.find({}, { _id: 1, name: 1 }).sort({ name: 1 });
    res.json(machines);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}

export async function submitParameters(req, res) {
  try {
    const { machineId, parameters } = req.body;
    if (!machineId || !parameters) {
      return res.status(400).json({ message: 'machineId and parameters are required' });
    }

    // optional: validate machine exists
    const machine = await Machine.findById(machineId);
    if (!machine) return res.status(404).json({ message: 'Machine not found' });

    const submission = new MachineSubmission({ machineId, parameters });
    await submission.save();

    res.json({ message: 'Submission saved', submissionId: submission._id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: err.message });
  }
}
